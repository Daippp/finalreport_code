import torch
from torch_geometric.nn import GCNConv
from torch.nn import Sequential, ReLU, Linear

class DGI(torch.nn.Module):
    def __init__(self, in_channels, out_channels, hidden_channels):
        super(DGI, self).__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, out_channels)
        self.act = ReLU()
        self.lin = Linear(out_channels, out_channels)

    def forward(self, x, edge_index):
        # 第一层GCN
        x = self.conv1(x, edge_index)
        x = self.act(x)
        # 第二层GCN
        x = self.conv2(x, edge_index)
        x = self.act(x)
        # 线性层
        x = self.lin(x)
        return x
