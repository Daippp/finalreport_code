import torch
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, BatchNorm, global_mean_pool
from torch.optim import Adam


class ImprovedGCNResNetBlock(nn.Module):
    def __init__(self, in_channels, hidden_channels, reduced_channels):
        super(ImprovedGCNResNetBlock, self).__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.batch_norm1 = BatchNorm(hidden_channels)
        self.conv2 = GCNConv(hidden_channels, reduced_channels)
        self.batch_norm2 = BatchNorm(reduced_channels)
        self.conv3 = GCNConv(reduced_channels, hidden_channels)
        self.batch_norm3 = BatchNorm(hidden_channels)
        self.dropout = nn.Dropout(0.5)
        # 修改shortcut以确保维度匹配
        self.shortcut = nn.Sequential(
            nn.Linear(in_channels, hidden_channels, bias=False),
            BatchNorm(hidden_channels)
        ) if in_channels != hidden_channels else nn.Identity()

    def forward(self, x, edge_index):
        identity = self.shortcut(x)
        out = F.relu(self.batch_norm1(self.conv1(x, edge_index)))
        out = self.dropout(out)
        out = F.relu(self.batch_norm2(self.conv2(out, edge_index)))
        out = self.dropout(out)
        out = self.batch_norm3(self.conv3(out, edge_index))
        out = F.relu(out + identity)  # 使用ReLU激活函数后再进行残差连接
        return out


class ImprovedFeaturePropagationNet(nn.Module):
    def __init__(self, in_channels, hidden_channels, reduced_channels):
        super(ImprovedFeaturePropagationNet, self).__init__()
        self.resnet_block1 = ImprovedGCNResNetBlock(in_channels, hidden_channels, reduced_channels)
        self.resnet_block2 = ImprovedGCNResNetBlock(hidden_channels, hidden_channels, reduced_channels)

    def forward(self, x, edge_index):
        x = self.resnet_block1(x, edge_index)
        x = self.resnet_block2(x, edge_index)
        return x


class GCNResNetBlock(nn.Module):
    def __init__(self, in_channels, hidden_channels):
        super(GCNResNetBlock, self).__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.batch_norm1 = BatchNorm(hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.batch_norm2 = BatchNorm(hidden_channels)
        self.dropout = nn.Dropout(0.5)
        # 修改shortcut以确保维度匹配
        self.shortcut = nn.Sequential(
            nn.Linear(in_channels, hidden_channels, bias=False),
            BatchNorm(hidden_channels)
        ) if in_channels != hidden_channels else nn.Identity()

    def forward(self, x, edge_index):
        identity = self.shortcut(x)
        out = F.relu(self.batch_norm1(self.conv1(x, edge_index)))
        out = self.dropout(out)
        out = self.batch_norm2(self.conv2(out, edge_index))
        out = F.relu(out + identity)  # 使用ReLU激活函数后再进行残差连接
        return out


class FeaturePropagationNet(nn.Module):
    def __init__(self, in_channels, hidden_channels):
        super(FeaturePropagationNet, self).__init__()
        self.resnet_block1 = GCNResNetBlock(in_channels, hidden_channels)
        self.resnet_block2 = GCNResNetBlock(hidden_channels, hidden_channels)

    def forward(self, x, edge_index):
        x = self.resnet_block1(x, edge_index)
        x = self.resnet_block2(x, edge_index)
        return x


class DownstreamTaskNet(nn.Module):
    def __init__(self, hidden_channels, num_classes):
        super(DownstreamTaskNet, self).__init__()
        self.lin = nn.Linear(hidden_channels, num_classes)

    def forward(self, x):
        return self.lin(x)


class End2EndModel(nn.Module):
    def __init__(self, in_channels, hidden_channels, num_classes, learning_rate=0.001, device='cpu'):
        super(End2EndModel, self).__init__()
        self.device = device
        self.feature_propagation_net = FeaturePropagationNet(in_channels, hidden_channels).to(device)
        self.downstream_task_net = DownstreamTaskNet(hidden_channels, num_classes).to(device)
        self.optimizer = Adam(self.parameters(), lr=learning_rate)

    def forward(self, x, edge_index, label=None):
        x = self.feature_propagation_net(x, edge_index)
        x = self.downstream_task_net(x)
        if label is not None:
            loss = F.nll_loss(F.log_softmax(x, dim=1), label)
            return loss
        else:
            return F.log_softmax(x, dim=1)

    def predict(self, x, edge_index):
        x = self.feature_propagation_net(x, edge_index)
        x = self.downstream_task_net(x)
        return F.log_softmax(x, dim=1)

    def train_model(self, data):
        self.train()
        self.optimizer.zero_grad()
        loss = self.forward(data.x.to(self.device), data.edge_index.to(self.device), data.y.to(self.device))
        loss.backward()
        self.optimizer.step()
        return loss.item()

    def evaluate(self, data):
        self.eval()
        logits = self.predict(data.x.to(self.device), data.edge_index.to(self.device))
        pred = logits.max(1)[1]
        correct = pred.eq(data.y.to(self.device)).sum().item()
        acc = correct / len(data.y)
        return acc
