import torch
from torch_geometric.nn import GCNConv
import torch.nn.functional as F


class GCNMISS(torch.nn.Module):
    def __init__(self, num_features, num_classes, hidden_channels):
        super(GCNMISS, self).__init__()
        self.conv1 = GCNConv(num_features, hidden_channels)
        self.conv2 = GCNConv(hidden_channels + num_features, num_classes)  # 加入残差连接
        self.num_features = num_features

    def forward(self, x, edge_index):
        # 第一层GCN
        x1 = F.relu(self.conv1(x, edge_index))

        # 残差连接
        x2 = torch.cat([x1, x], dim=1)  # 将输入特征与第一层输出特征相连

        # 第二层GCN
        x3 = self.conv2(x2, edge_index)

        return F.log_softmax(x3, dim=1)