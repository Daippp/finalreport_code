import torch
import torch.nn as nn

class SequencePredictionLoss(nn.Module):
    """
    前向和损失，用于链式预测任务。
    """
    def __init__(self):
        super(SequencePredictionLoss, self).__init__()
        self.loss_fn = nn.CrossEntropyLoss()

    def forward(self, outputs, targets):
        # 计算每个时间步的损失，并求和
        total_loss = 0
        for output, target in zip(outputs, targets):
            total_loss += self.loss_fn(output, target)
        return total_loss

class MultiLabelClassificationLoss(nn.Module):
    """
    多标签分类的交叉熵损失。
    """
    def __init__(self):
        super(MultiLabelClassificationLoss, self).__init__()
        self.loss_fn = nn.BCEWithLogitsLoss()

    def forward(self, outputs, targets):
        return self.loss_fn(outputs, targets)
